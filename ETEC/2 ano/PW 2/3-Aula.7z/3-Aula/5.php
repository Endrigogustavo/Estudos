
<html>
<head>
    
    <title>Pagina tabuada php</title>
</head>
<body>
    <?php

    $i = 0;
    while($i<= 10){
        $tab = 2*$i;
        echo'2'.'X'.$i.'=' .$tab.'<br/>';
        $i++;
    }

    ?>
</body>
</html>
<html>
<head>
    
    <title>Pagina tabuada php</title>
</head>
<body>
    <?php

    $i = 0;
    
    do{
        $tab = 2*$i;
        echo'2'.'X'.$i.'=' .$tab.'<br/>';
        $i++;
        }while($i<= 10)
    ?>
</body>
</html>

<!--for( $i = 1; $i <= 5; $i++ ){            echo $i .'<br />';
    for($i = 5; $i >=1; $i--){        echo $i .'<br />'; }-->